"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import Header from "@/components/header"
import { Badge } from "@/components/ui/badge"
import { Mail, MapPin, LinkIcon, Github, Linkedin, Trophy, Users, Target } from "lucide-react"

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false)

  const userProfile = {
    name: "Marcus Johnson",
    role: "Engineering Lead",
    bio: "Passionate about building sustainable technology solutions. Love collaborating with teams to bring ideas to life.",
    location: "San Francisco, CA",
    email: "marcus@hackjam.com",
    website: "marcusjohnson.dev",
    github: "github.com/marcus",
    linkedin: "linkedin.com/in/marcus",
    joinedDate: "Jan 2024",
    expertise: ["Full Stack", "React", "Node.js", "System Design", "Team Leadership"],
    achievements: [
      { icon: Trophy, title: "Hackathon Winner", desc: "Won 3 hackathons" },
      { icon: Users, title: "Team Builder", desc: "Led 12 projects" },
      { icon: Target, title: "Innovator", desc: "48 ideas posted" },
    ],
  }

  return (
    <div className="min-h-screen bg-background">
      <Header onMobileMenuToggle={() => {}} />

      <main className="max-w-4xl mx-auto px-4 lg:px-6 py-6">
        {/* Profile Header Card */}
        <Card className="mb-6 overflow-hidden">
          {/* Cover Background */}
          <div className="h-32 bg-gradient-to-r from-primary/20 to-accent/20" />

          {/* Profile Info */}
          <div className="px-6 pb-6">
            <div className="flex flex-col md:flex-row md:items-end gap-6 -mt-16 mb-6">
              <Avatar className="w-32 h-32 border-4 border-card">
                <AvatarFallback className="bg-primary text-primary-foreground text-lg font-bold">MJ</AvatarFallback>
              </Avatar>

              <div className="flex-1">
                <h1 className="text-3xl font-bold text-foreground">{userProfile.name}</h1>
                <p className="text-accent text-lg font-medium">{userProfile.role}</p>
              </div>

              {!isEditing && (
                <Button
                  onClick={() => setIsEditing(true)}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground md:ml-auto"
                >
                  Edit Profile
                </Button>
              )}
            </div>

            {/* Bio */}
            <p className="text-muted-foreground mb-4">{userProfile.bio}</p>

            {/* Contact Info */}
            <div className="flex flex-wrap gap-4 mb-4 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <MapPin className="w-4 h-4" />
                {userProfile.location}
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Mail className="w-4 h-4" />
                {userProfile.email}
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <LinkIcon className="w-4 h-4" />
                {userProfile.website}
              </div>
            </div>

            {/* Social Links */}
            <div className="flex gap-3">
              <Button variant="outline" size="sm" className="flex items-center gap-2 bg-transparent">
                <Github className="w-4 h-4" />
                GitHub
              </Button>
              <Button variant="outline" size="sm" className="flex items-center gap-2 bg-transparent">
                <Linkedin className="w-4 h-4" />
                LinkedIn
              </Button>
            </div>
          </div>
        </Card>

        {/* Stats and Achievements */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {userProfile.achievements.map((achievement, idx) => {
            const Icon = achievement.icon
            return (
              <Card key={idx} className="p-6 flex flex-col items-center text-center">
                <Icon className="w-8 h-8 text-primary mb-3" />
                <h3 className="font-semibold text-foreground mb-1">{achievement.title}</h3>
                <p className="text-sm text-muted-foreground">{achievement.desc}</p>
              </Card>
            )
          })}
        </div>

        {/* Expertise Tags */}
        <Card className="p-6 mb-6">
          <h2 className="font-semibold text-foreground mb-4">Expertise</h2>
          <div className="flex flex-wrap gap-2">
            {userProfile.expertise.map((skill) => (
              <Badge key={skill} variant="secondary">
                {skill}
              </Badge>
            ))}
          </div>
        </Card>

        {/* Featured Projects */}
        <Card className="p-6 mb-6">
          <h2 className="font-semibold text-foreground mb-4">Featured Projects</h2>
          <div className="space-y-4">
            {[
              {
                title: "Campus Energy Optimization",
                desc: "AI-driven system to monitor and reduce campus energy consumption",
                status: "Active",
              },
              { title: "Green Tech Challenge", desc: "Real-time pollution monitoring solution", status: "Completed" },
              {
                title: "Sustainability Dashboard",
                desc: "Interactive platform for tracking environmental impact",
                status: "In Development",
              },
            ].map((project, idx) => (
              <div key={idx} className="p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-medium text-foreground">{project.title}</h3>
                  <Badge variant={project.status === "Active" ? "default" : "outline"}>{project.status}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">{project.desc}</p>
              </div>
            ))}
          </div>
        </Card>

        {/* Activity Stats */}
        <Card className="p-6">
          <h2 className="font-semibold text-foreground mb-4">Member Since</h2>
          <p className="text-foreground text-lg font-medium">{userProfile.joinedDate}</p>
          <p className="text-sm text-muted-foreground mt-2">Active contributor to the HackJam community</p>
        </Card>
      </main>
    </div>
  )
}

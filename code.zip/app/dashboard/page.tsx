"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts"
import Header from "@/components/header"
import { TrendingUp, Users, Zap, Award } from "lucide-react"

const engagementData = [
  { month: "Jan", engagement: 400, posts: 24 },
  { month: "Feb", engagement: 520, posts: 28 },
  { month: "Mar", engagement: 480, posts: 32 },
  { month: "Apr", engagement: 680, posts: 36 },
  { month: "May", engagement: 750, posts: 42 },
  { month: "Jun", engagement: 920, posts: 48 },
]

const recentActivity = [
  { id: 1, action: "Posted idea", title: "Campus Energy Optimization Tool", time: "2h ago" },
  { id: 2, action: "Collaborated on", title: "Green Tech Challenge", time: "5h ago" },
  { id: 3, action: "Liked post by", title: "Sarah Chen", time: "1d ago" },
  { id: 4, action: "Joined event", title: "Hackathon Kickoff", time: "2d ago" },
]

export default function Dashboard() {
  const [period, setPeriod] = useState("6m")

  return (
    <div className="min-h-screen bg-background">
      <Header onMobileMenuToggle={() => {}} />

      <main className="max-w-6xl mx-auto px-4 lg:px-6 py-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Your Dashboard</h1>
          <p className="text-muted-foreground">Track your progress and engagement metrics</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Ideas Posted</p>
                <p className="text-2xl font-bold text-foreground">48</p>
                <p className="text-xs text-accent mt-2">+12% this month</p>
              </div>
              <Zap className="w-8 h-8 text-accent opacity-20" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Total Engagement</p>
                <p className="text-2xl font-bold text-foreground">2,847</p>
                <p className="text-xs text-primary mt-2">+23% this month</p>
              </div>
              <TrendingUp className="w-8 h-8 text-primary opacity-20" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Collaborators</p>
                <p className="text-2xl font-bold text-foreground">24</p>
                <p className="text-xs text-accent mt-2">+5 new this month</p>
              </div>
              <Users className="w-8 h-8 text-accent opacity-20" />
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground mb-1">Reward Points</p>
                <p className="text-2xl font-bold text-foreground">3,240</p>
                <p className="text-xs text-primary mt-2">Next rank: Elite</p>
              </div>
              <Award className="w-8 h-8 text-primary opacity-20" />
            </div>
          </Card>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card className="lg:col-span-2 p-6">
            <div className="mb-4">
              <h2 className="font-semibold text-foreground mb-4">Engagement Over Time</h2>
              <div className="flex gap-2 mb-4">
                <Button variant={period === "1m" ? "default" : "outline"} onClick={() => setPeriod("1m")} size="sm">
                  1M
                </Button>
                <Button variant={period === "3m" ? "default" : "outline"} onClick={() => setPeriod("3m")} size="sm">
                  3M
                </Button>
                <Button variant={period === "6m" ? "default" : "outline"} onClick={() => setPeriod("6m")} size="sm">
                  6M
                </Button>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={engagementData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="month" stroke="var(--color-muted-foreground)" />
                <YAxis stroke="var(--color-muted-foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderRadius: "8px",
                  }}
                />
                <Line type="monotone" dataKey="engagement" stroke="var(--color-primary)" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          <Card className="p-6">
            <h2 className="font-semibold text-foreground mb-4">Top Contributors</h2>
            <div className="space-y-3">
              {[
                { name: "Sarah Chen", role: "Designer", score: 1240 },
                { name: "Marcus Johnson", role: "Engineer", score: 1100 },
                { name: "Emma Davis", role: "PM", score: 980 },
                { name: "Alex Lee", role: "Designer", score: 850 },
              ].map((contributor, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <Avatar className="w-8 h-8">
                    <AvatarFallback className="bg-primary/20 text-primary text-xs">
                      {contributor.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground">{contributor.name}</p>
                    <p className="text-xs text-muted-foreground">{contributor.role}</p>
                  </div>
                  <p className="text-sm font-semibold text-accent">{contributor.score}</p>
                </div>
              ))}
            </div>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card className="p-6">
          <h2 className="font-semibold text-foreground mb-4">Recent Activity</h2>
          <div className="space-y-4">
            {recentActivity.map((activity) => (
              <div
                key={activity.id}
                className="flex items-start gap-4 pb-4 border-b border-border last:border-0 last:pb-0"
              >
                <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground">
                    <span className="font-medium">{activity.action}</span>{" "}
                    <span className="text-muted-foreground truncate">{activity.title}</span>
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </main>
    </div>
  )
}

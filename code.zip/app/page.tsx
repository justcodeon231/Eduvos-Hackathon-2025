"use client"

import { useState } from "react"
import Header from "@/components/header"
import MainFeed from "@/components/main-feed"
import Sidebar from "@/components/sidebar"
import MobileNav from "@/components/mobile-nav"

export default function Home() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  return (
    <div className="min-h-screen bg-background">
      <Header onMobileMenuToggle={() => setIsMobileMenuOpen(!isMobileMenuOpen)} />

      <div className="flex">
        {/* Main Content */}
        <main className="flex-1 max-w-4xl mx-auto w-full px-4 lg:px-6 py-6 lg:border-r border-border">
          <MainFeed />
        </main>

        {/* Sidebar - Hidden on mobile, shown on lg screens */}
        <aside className="hidden lg:block w-80 px-6 py-6 border-l border-border">
          <Sidebar />
        </aside>
      </div>

      {/* Mobile Navigation */}
      <MobileNav />
    </div>
  )
}

"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Heart, MessageCircle, Share2, Bookmark } from "lucide-react"

export default function MainFeed() {
  const [posts, setPosts] = useState([
    {
      id: 1,
      author: "Sarah Chen",
      role: "Product Designer",
      avatar: "SC",
      timeAgo: "2h ago",
      title: "Campus Energy Optimization Tool",
      content:
        "Built an AI-driven system to monitor and reduce campus consumption using predictive models. Looking for developers to help scale this to other universities.",
      tags: ["#Sustainability", "#AI", "#IoT"],
      likes: 342,
      comments: 28,
      liked: false,
      category: "IdeaHub",
    },
    {
      id: 2,
      author: "Marcus Johnson",
      role: "Engineering Lead",
      avatar: "MJ",
      timeAgo: "5h ago",
      title: "Hackathon Results: Green Tech Challenge",
      content:
        "Amazing energy and creativity at this week's hackathon. Our team built a real-time pollution monitor. Excited to collaborate with the winners on the next phase.",
      tags: ["#Hackathon", "#TeamWork", "#GreenTech"],
      likes: 215,
      comments: 42,
      liked: false,
      category: "Events",
    },
  ])

  const handleLike = (postId: number) => {
    setPosts(
      posts.map((post) =>
        post.id === postId
          ? { ...post, liked: !post.liked, likes: post.liked ? post.likes - 1 : post.likes + 1 }
          : post,
      ),
    )
  }

  return (
    <div className="space-y-6">
      {/* Create Post Card */}
      <Card className="p-4 lg:p-6">
        <div className="flex gap-3 mb-4">
          <Avatar className="w-10 h-10">
            <AvatarFallback className="bg-primary text-primary-foreground">You</AvatarFallback>
          </Avatar>
          <textarea
            placeholder="Share an idea, opportunity, or update..."
            className="flex-1 p-3 bg-muted rounded-lg text-sm placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none min-h-[80px]"
          />
        </div>

        <div className="flex items-center justify-between gap-3">
          <div className="flex gap-2">
            <button className="flex items-center gap-2 px-3 py-2 hover:bg-muted rounded-lg transition-colors text-sm text-muted-foreground">
              <span className="text-lg">#</span>
              <span>Tag</span>
            </button>
            <button className="flex items-center gap-2 px-3 py-2 hover:bg-muted rounded-lg transition-colors text-sm text-muted-foreground">
              <span>📎</span>
              <span>Media</span>
            </button>
          </div>
          <Button className="bg-primary hover:bg-primary/90 text-primary-foreground">Post</Button>
        </div>
      </Card>

      {/* Posts Feed */}
      <div className="space-y-4">
        {posts.map((post) => (
          <Card key={post.id} className="p-4 lg:p-6 hover:shadow-md transition-shadow">
            {/* Post Header */}
            <div className="flex gap-3 mb-4">
              <Avatar className="w-10 h-10">
                <AvatarFallback className="bg-secondary text-secondary-foreground">{post.avatar}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-semibold text-foreground text-sm">{post.author}</p>
                  <span className="text-xs text-muted-foreground">{post.role}</span>
                </div>
                <p className="text-xs text-muted-foreground">{post.timeAgo}</p>
              </div>
              <span className="text-xs px-2 py-1 bg-accent/10 text-accent rounded-full">{post.category}</span>
            </div>

            {/* Post Content */}
            <h3 className="text-base lg:text-lg font-semibold text-foreground mb-2">{post.title}</h3>
            <p className="text-sm text-muted-foreground mb-3 leading-relaxed">{post.content}</p>

            {/* Tags */}
            <div className="flex flex-wrap gap-2 mb-4">
              {post.tags.map((tag) => (
                <span
                  key={tag}
                  className="text-xs px-3 py-1 bg-primary/10 text-primary rounded-full hover:bg-primary/20 transition-colors cursor-pointer"
                >
                  {tag}
                </span>
              ))}
            </div>

            {/* Post Stats and Actions */}
            <div className="flex items-center justify-between text-sm text-muted-foreground border-t border-border pt-3">
              <div className="flex gap-4">
                <button
                  onClick={() => handleLike(post.id)}
                  className={`flex items-center gap-2 transition-colors ${
                    post.liked ? "text-primary" : "hover:text-primary"
                  }`}
                >
                  <Heart className={`w-4 h-4 ${post.liked ? "fill-current" : ""}`} />
                  <span className="text-xs">{post.likes}</span>
                </button>
                <button className="flex items-center gap-2 hover:text-accent transition-colors">
                  <MessageCircle className="w-4 h-4" />
                  <span className="text-xs">{post.comments}</span>
                </button>
              </div>
              <div className="flex gap-2">
                <Share2 className="w-4 h-4 cursor-pointer hover:text-primary transition-colors" />
                <Bookmark className="w-4 h-4 cursor-pointer hover:text-accent transition-colors" />
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}

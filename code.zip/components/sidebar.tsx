"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Calendar, Clock, AlertCircle, Trophy } from "lucide-react"

export default function Sidebar() {
  const [selectedDate, setSelectedDate] = useState(25)

  const upcomingEvents = [
    { title: "Green Tech Hackathon", date: "Fri 5 PM", type: "event" },
    { title: "Pitch workshop", date: "Sat 10 AM", type: "workshop" },
    { title: "Networking brunch", date: "Sun 11 AM", type: "social" },
  ]

  return (
    <div className="space-y-6">
      {/* Calendar Card */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-foreground">September</h3>
          <span className="text-xs font-medium px-3 py-1 bg-primary/10 text-primary rounded-full">Today</span>
        </div>

        {/* Calendar Grid */}
        <div className="grid grid-cols-7 gap-1 mb-6">
          {["S", "M", "T", "W", "T", "F", "S"].map((day) => (
            <div key={day} className="text-center text-xs font-medium text-muted-foreground py-2">
              {day}
            </div>
          ))}
          {Array.from({ length: 35 }, (_, i) => {
            const day = i - 5 + 1
            if (day < 1 || day > 30) {
              return <div key={i} className="aspect-square" />
            }
            const isToday = day === 25
            const isEvent = [5, 12, 20, 27].includes(day)
            return (
              <button
                key={i}
                onClick={() => setSelectedDate(day)}
                className={`aspect-square flex items-center justify-center text-sm font-medium rounded-lg transition-all ${
                  isToday
                    ? "bg-primary text-primary-foreground"
                    : selectedDate === day
                      ? "bg-accent/20 text-accent border border-accent"
                      : isEvent
                        ? "bg-secondary/20 text-secondary"
                        : "text-foreground hover:bg-muted"
                }`}
              >
                {day}
              </button>
            )
          })}
        </div>

        {/* Events List */}
        <div className="space-y-3 border-t border-border pt-4">
          {upcomingEvents.map((event, idx) => (
            <div key={idx} className="flex gap-3 text-sm">
              <div className="mt-1 flex-shrink-0">
                {event.type === "event" ? (
                  <Calendar className="w-4 h-4 text-primary" />
                ) : (
                  <Clock className="w-4 h-4 text-accent" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground truncate">{event.title}</p>
                <p className="text-xs text-muted-foreground">{event.date}</p>
              </div>
            </div>
          ))}
        </div>

        <Button className="w-full mt-4 bg-primary hover:bg-primary/90 text-primary-foreground">View More Events</Button>
      </Card>

      {/* Dashboard Card */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="font-semibold text-foreground">Your Dashboard</h3>
          <Trophy className="w-5 h-5 text-accent" />
        </div>

        <div className="space-y-4">
          {/* Stats */}
          <div>
            <p className="text-xs text-muted-foreground mb-1">Ideas Posted</p>
            <p className="text-2xl font-bold text-foreground">24</p>
          </div>

          <div>
            <p className="text-xs text-muted-foreground mb-1">Engagement Score</p>
            <div className="flex items-end gap-2">
              <p className="text-2xl font-bold text-foreground">8,420</p>
              <span className="text-xs text-accent">+12%</span>
            </div>
          </div>

          <div className="pt-3 border-t border-border">
            <p className="text-xs text-muted-foreground mb-1">Collaborators</p>
            <div className="flex -space-x-2">
              {["A", "B", "C"].map((initial, idx) => (
                <Avatar key={idx} className="w-6 h-6 border-2 border-card">
                  <AvatarFallback className="bg-accent text-accent-foreground text-xs">{initial}</AvatarFallback>
                </Avatar>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-border">
            <p className="text-xs text-muted-foreground mb-1">Reward Points</p>
            <p className="text-2xl font-bold text-foreground">1,340</p>
          </div>
        </div>

        <Button variant="outline" className="w-full mt-4 bg-transparent">
          View Full Profile
        </Button>
      </Card>

      {/* Tips Card */}
      <Card className="p-4 bg-accent/5 border-accent/20">
        <div className="flex gap-3">
          <AlertCircle className="w-5 h-5 text-accent flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-xs font-semibold text-foreground mb-1">Did you know?</p>
            <p className="text-xs text-muted-foreground">
              Posting consistently increases your engagement. Try posting once a week!
            </p>
          </div>
        </div>
      </Card>
    </div>
  )
}

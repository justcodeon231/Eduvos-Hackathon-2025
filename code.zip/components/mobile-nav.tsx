"use client"

import type React from "react"

import { Home, FileText, Calendar, Users, Trophy } from "lucide-react"

export default function MobileNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card border-t border-border lg:hidden flex items-center justify-around py-2">
      <NavItem icon={Home} label="Home" active />
      <NavItem icon={FileText} label="Ideas" />
      <NavItem icon={Calendar} label="Events" />
      <NavItem icon={Users} label="Connect" />
      <NavItem icon={Trophy} label="Leaderboard" />
    </nav>
  )
}

function NavItem({ icon: Icon, label, active }: { icon: React.ReactType; label: string; active?: boolean }) {
  return (
    <button className="flex flex-col items-center gap-1 px-3 py-2 rounded-lg transition-colors flex-1">
      <Icon className={`w-5 h-5 ${active ? "text-primary" : "text-muted-foreground"}`} />
      <span className={`text-xs font-medium ${active ? "text-primary" : "text-muted-foreground"}`}>{label}</span>
    </button>
  )
}

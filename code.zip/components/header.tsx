"use client"

import { Search, Bell, User, Menu, X } from "lucide-react"
import { useState } from "react"

interface HeaderProps {
  onMobileMenuToggle: () => void
}

export default function Header({ onMobileMenuToggle }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false)

  const handleMenuToggle = () => {
    setIsOpen(!isOpen)
    onMobileMenuToggle()
  }

  return (
    <header className="sticky top-0 z-50 bg-card border-b border-border">
      {/* Main Header */}
      <div className="px-4 lg:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-4 lg:gap-8 flex-1">
          {/* Logo */}
          <div className="flex items-center gap-2 min-w-max">
            <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-primary-foreground text-sm font-bold">H</span>
            </div>
            <span className="font-semibold text-foreground hidden md:inline">HackJam</span>
          </div>

          {/* Search - Hidden on mobile */}
          <div className="relative hidden md:flex flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <input
              type="text"
              placeholder="Search ideas, projects..."
              className="w-full pl-10 pr-4 py-2 bg-muted rounded-lg text-sm text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-0"
            />
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-3">
          <Search className="w-5 h-5 text-muted-foreground md:hidden cursor-pointer" />
          <Bell className="w-5 h-5 text-muted-foreground cursor-pointer hover:text-foreground transition-colors" />
          <User className="w-5 h-5 text-muted-foreground cursor-pointer hover:text-foreground transition-colors" />

          {/* Mobile Menu Toggle */}
          <button onClick={handleMenuToggle} className="md:hidden ml-2">
            {isOpen ? <X className="w-5 h-5 text-foreground" /> : <Menu className="w-5 h-5 text-foreground" />}
          </button>
        </div>
      </div>

      {/* Navigation Tabs - Horizontal on desktop, hidden on mobile */}
      <nav className="hidden md:flex border-t border-border px-6">
        <NavigationTab label="Home" active />
        <NavigationTab label="Ideas" />
        <NavigationTab label="Events" />
        <NavigationTab label="Collaborate" />
        <NavigationTab label="Leaderboard" />
      </nav>

      {/* Mobile Navigation Tabs */}
      <nav className="md:hidden border-t border-border px-4 flex gap-4 overflow-x-auto pb-3 pt-3">
        <NavigationTab label="Home" active mobile />
        <NavigationTab label="Ideas" mobile />
        <NavigationTab label="Events" mobile />
      </nav>
    </header>
  )
}

function NavigationTab({ label, active, mobile }: { label: string; active?: boolean; mobile?: boolean }) {
  return (
    <button
      className={`py-3 text-sm font-medium whitespace-nowrap transition-colors ${
        active ? "text-primary border-b-2 border-primary" : "text-muted-foreground hover:text-foreground"
      } ${mobile ? "pb-0" : ""}`}
    >
      {label}
    </button>
  )
}
